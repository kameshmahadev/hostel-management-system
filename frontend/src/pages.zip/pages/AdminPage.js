const AdminPage = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold text-green-700">Admin Panel</h1>
      <p>Only accessible to users with the <strong>admin</strong> role.</p>
    </div>
  );
};

export default AdminPage;
